const STORAGE_KEY = "sp_board_v1";
const wrap=document.getElementById("wrap"),canvas=document.getElementById("canvas"),svg=document.getElementById("edges");
const nodeListEl=document.getElementById("node-list"),countEl=document.getElementById("count");
const mini=document.getElementById("mini"),miniVp=document.getElementById("mini-vp");
let state={nodes:[],edges:[]},scale=1,panX=0,panY=0,selectedId=null,connectMode=false,connectFrom=null,rafPending=false;
const TYPE_LABEL={person:"Человек",username:"Ник",email:"Email",phone:"Телефон",ip:"IP",domain:"Домен",location:"Локация",note:"Заметка"};
const TYPE_COLOR={person:"#5fb0ff",username:"#7ee2c3",email:"#ffd166",phone:"#ff9f6b",ip:"#c792ea",domain:"#6bd1ff",location:"#ff6b9f",note:"#94a3b8"};
const uid=()=>Math.random().toString(36).slice(2,10);
const esc=(s)=>(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const nodeEls = new Map(); // id -> DOM element

function save(){chrome.storage.local.set({[STORAGE_KEY]:state});}
function load(){chrome.storage.local.get([STORAGE_KEY],(res)=>{if(res[STORAGE_KEY])state=res[STORAGE_KEY];render();fitAll();});}

function applyTransform(){
  canvas.style.transform=`translate(${panX}px, ${panY}px) scale(${scale})`;
  svg.style.transform=canvas.style.transform;
  document.getElementById("zoom-level").textContent=Math.round(scale*100)+"%";
  // компенсируем толщину линий при уменьшении/увеличении
  svg.querySelectorAll("path").forEach(p=>{
    p.setAttribute("stroke-width", (2 / scale).toString());
  });
  updateMini();
}

// Точный центр карточки в координатах «мира» через offsetWidth/offsetHeight
function nodeCenter(n){
  const el = nodeEls.get(n.id);
  const w = el ? el.offsetWidth  : 210;
  const h = el ? el.offsetHeight : 70;
  return { x: n.x + w/2, y: n.y + h/2 };
}

function drawEdges(target){
  // очищаем только paths, не трогая ничего другого
  target.querySelectorAll("path").forEach(p=>p.remove());
  state.edges.forEach(e=>{
    const a=state.nodes.find(n=>n.id===e.from),b=state.nodes.find(n=>n.id===e.to);
    if(!a||!b)return;
    const ca=nodeCenter(a),cb=nodeCenter(b);
    const path=document.createElementNS("http://www.w3.org/2000/svg","path");
    const mx=(ca.x+cb.x)/2,my=(ca.y+cb.y)/2-40;
    path.setAttribute("d",`M ${ca.x} ${ca.y} Q ${mx} ${my} ${cb.x} ${cb.y}`);
    path.setAttribute("stroke","#3b8dff");
    path.setAttribute("stroke-width",(2/scale).toString());
    path.setAttribute("fill","none");
    path.setAttribute("stroke-linecap","round");
    path.setAttribute("opacity","0.75");
    path.dataset.edge = e.id;
    target.appendChild(path);
  });
}

function render(){
  canvas.innerHTML="";
  nodeEls.clear();
  countEl.textContent=state.nodes.length;

  state.nodes.forEach(n=>{
    const el=document.createElement("div");
    el.className="b-node"+(n.id===selectedId?" selected":"");
    el.dataset.type=n.type;
    el.dataset.id=n.id;
    el.style.left=n.x+"px";
    el.style.top=n.y+"px";
    el.innerHTML=`<div class="head"><span class="sp-badge" style="background:${hexA(TYPE_COLOR[n.type],.15)};color:${TYPE_COLOR[n.type]};border-color:${hexA(TYPE_COLOR[n.type],.4)}">${TYPE_LABEL[n.type]}</span><span class="del" title="Удалить">✕</span></div><div class="ttl">${esc(n.title)}</div><div class="body" contenteditable="true" spellcheck="false">${esc(n.note||"")}</div>`;
    canvas.appendChild(el);
    nodeEls.set(n.id, el);

    let dragging=false,lastX=0,lastY=0;
    el.addEventListener("mousedown",(ev)=>{
      if(ev.target.classList.contains("del"))return;
      if(ev.target.isContentEditable)return;
      if(connectMode){
        if(!connectFrom){connectFrom=n.id;el.classList.add("selected");}
        else{addEdge(connectFrom,n.id);connectFrom=null;}
        ev.stopPropagation();return;
      }
      dragging=true;selectedId=n.id;
      lastX=ev.clientX;lastY=ev.clientY;
      el.classList.add("dragging");
      ev.stopPropagation();
    });
    const onMove=(ev)=>{
      if(!dragging)return;
      const dx=(ev.clientX-lastX)/scale,dy=(ev.clientY-lastY)/scale;
      lastX=ev.clientX;lastY=ev.clientY;
      n.x+=dx;n.y+=dy;
      el.style.left=n.x+"px";
      el.style.top=n.y+"px";
      drawEdges(svg);
    };
    const onUp=()=>{
      if(dragging){
        dragging=false;
        el.classList.remove("dragging");
        save();
      }
    };
    document.addEventListener("mousemove",onMove);
    document.addEventListener("mouseup",onUp);

    el.addEventListener("contextmenu",(ev)=>{ev.preventDefault();if(confirm(`Удалить «${n.title}»?`))deleteNode(n.id);});
    el.querySelector(".del").addEventListener("click",(ev)=>{ev.stopPropagation();deleteNode(n.id);});
    el.querySelector(".body").addEventListener("blur",(ev)=>{
      n.note=ev.target.textContent;
      save();
      // после изменения размера текста — пересчёт линий
      requestAnimationFrame(()=>drawEdges(svg));
    });
    // если размеры карточки поменялись — перерисуем линии
    if (window.ResizeObserver) {
      const ro = new ResizeObserver(()=>drawEdges(svg));
      ro.observe(el);
      el._ro = ro;
    }
  });

  drawEdges(svg);
  renderSidebar();
  updateMini();
}

function addNode(type,sx,sy){
  const title=type==="note"?"Новая заметка":prompt(`Значение (${TYPE_LABEL[type]}):`,"");
  if(title===null)return;
  state.nodes.push({id:uid(),type,title:title||TYPE_LABEL[type],note:"",x:(sx-panX)/scale,y:(sy-panY)/scale});
  save();render();
}
function deleteNode(id){
  state.nodes=state.nodes.filter(n=>n.id!==id);
  state.edges=state.edges.filter(e=>e.from!==id&&e.to!==id);
  save();render();
}
function addEdge(a,b){
  if(a===b)return;
  if(state.edges.some(e=>(e.from===a&&e.to===b)||(e.from===b&&e.to===a)))return;
  state.edges.push({id:uid(),from:a,to:b});
  save();
  drawEdges(svg);
}
function renderSidebar(){
  const filter=(document.getElementById("filter").value||"").toLowerCase();
  nodeListEl.innerHTML="";
  state.nodes.filter(n=>n.title.toLowerCase().includes(filter)).forEach(n=>{
    const item=document.createElement("div");
    item.className="b-item";
    item.innerHTML=`<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(n.title)}</span><span class="sp-badge">${TYPE_LABEL[n.type]}</span>`;
    item.addEventListener("click",()=>{selectedId=n.id;focusNode(n);});
    nodeListEl.appendChild(item);
  });
}
function focusNode(n){
  const el = nodeEls.get(n.id);
  const w = el ? el.offsetWidth : 210;
  const h = el ? el.offsetHeight : 70;
  const vw=wrap.clientWidth,vh=wrap.clientHeight;
  const ts=Math.max(scale,1);
  panX=vw/2-n.x*ts-(w/2)*ts;
  panY=vh/2-n.y*ts-(h/2)*ts;
  scale=ts;
  applyTransform();
  render();
}
function updateMini(){
  if(!state.nodes.length)return;
  const r=mini.getBoundingClientRect(),pad=8,W=r.width-pad*2,H=r.height-pad*2;
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  state.nodes.forEach(n=>{const el=nodeEls.get(n.id);const w=el?el.offsetWidth:210,h=el?el.offsetHeight:70;minX=Math.min(minX,n.x);minY=Math.min(minY,n.y);maxX=Math.max(maxX,n.x+w);maxY=Math.max(maxY,n.y+h);});
  const spanX=Math.max(maxX-minX,1),spanY=Math.max(maxY-minY,1);
  const k=Math.min(W/spanX,H/spanY);
  const sx=(x)=>pad+(x-minX)*k, sy=(y)=>pad+(y-minY)*k;
  mini.querySelectorAll(".mdot").forEach(d=>d.remove());
  state.nodes.forEach(n=>{
    const el=nodeEls.get(n.id);const w=el?el.offsetWidth:210,h=el?el.offsetHeight:70;
    const d=document.createElement("div");d.className="mdot";d.style.left=sx(n.x+w/2)+"px";d.style.top=sy(n.y+h/2)+"px";mini.appendChild(d);
  });
  const vw=wrap.clientWidth,vh=wrap.clientHeight;
  const vx=-panX/scale,vy=-panY/scale,ww=vw/scale,hh=vh/scale;
  miniVp.style.left=sx(vx)+"px";miniVp.style.top=sy(vy)+"px";
  miniVp.style.width=Math.max(ww*k,8)+"px";miniVp.style.height=Math.max(hh*k,8)+"px";
}
function hexA(hex,a){const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);return`rgba(${r},${g},${b},${a})`;}
function fitAll(){
  if(!state.nodes.length)return;
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  state.nodes.forEach(n=>{const el=nodeEls.get(n.id);const w=el?el.offsetWidth:210,h=el?el.offsetHeight:70;minX=Math.min(minX,n.x);minY=Math.min(minY,n.y);maxX=Math.max(maxX,n.x+w);maxY=Math.max(maxY,n.y+h);});
  const w=wrap.clientWidth,h=wrap.clientHeight,pad=80;
  scale=Math.min((w-pad*2)/(maxX-minX),(h-pad*2)/(maxY-minY),1.2);
  panX=(w-(maxX-minX)*scale)/2-minX*scale;
  panY=(h-(maxY-minY)*scale)/2-minY*scale;
  applyTransform();
}
document.querySelectorAll(".b-type").forEach(btn=>{
  btn.addEventListener("click",()=>{const r=wrap.getBoundingClientRect();addNode(btn.dataset.type,r.width/2,r.height/2);});
});
document.getElementById("connect-mode").addEventListener("click",(e)=>{connectMode=!connectMode;connectFrom=null;e.currentTarget.classList.toggle("active",connectMode);});
document.getElementById("filter").addEventListener("input",renderSidebar);
document.getElementById("clear-btn").addEventListener("click",()=>{if(confirm("Удалить всё?")){state={nodes:[],edges:[]};save();render();}});
document.getElementById("export-btn").addEventListener("click",()=>{const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="solopool-board.json";a.click();URL.revokeObjectURL(url);});
document.getElementById("import-btn").addEventListener("click",()=>document.getElementById("import-file").click());
document.getElementById("import-file").addEventListener("change",(ev)=>{const f=ev.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(d.nodes&&d.edges){state=d;save();render();fitAll();}}catch{alert("Некорректный JSON");}};r.readAsText(f);});
wrap.addEventListener("dblclick",(ev)=>{if(ev.target!==wrap&&ev.target!==canvas)return;const r=wrap.getBoundingClientRect();addNode("note",ev.clientX-r.left,ev.clientY-r.top);});
let panning=false,psx=0,psy=0,pox=0,poy=0;
wrap.addEventListener("mousedown",(ev)=>{if(ev.target.closest(".b-node"))return;if(ev.button!==0&&ev.button!==1)return;panning=true;wrap.classList.add("grabbing");psx=ev.clientX;psy=ev.clientY;pox=panX;poy=panY;});
window.addEventListener("mousemove",(ev)=>{if(!panning)return;panX=pox+(ev.clientX-psx);panY=poy+(ev.clientY-psy);applyTransform();});
window.addEventListener("mouseup",()=>{panning=false;wrap.classList.remove("grabbing");});
wrap.addEventListener("wheel",(ev)=>{ev.preventDefault();const r=wrap.getBoundingClientRect(),mx=ev.clientX-r.left,my=ev.clientY-r.top,os=scale;scale=Math.min(3,Math.max(0.15,scale*(1-ev.deltaY*0.0018)));panX=mx-(mx-panX)*(scale/os);panY=my-(my-panY)*(scale/os);applyTransform();},{passive:false});
document.getElementById("zoom-in").addEventListener("click",()=>{scale=Math.min(3,scale+0.15);applyTransform();});
document.getElementById("zoom-out").addEventListener("click",()=>{scale=Math.max(0.15,scale-0.15);applyTransform();});
document.getElementById("zoom-fit").addEventListener("click",fitAll);
document.getElementById("zoom-reset").addEventListener("click",()=>{scale=1;panX=0;panY=0;applyTransform();});
window.addEventListener("resize",updateMini);
applyTransform();
load();
