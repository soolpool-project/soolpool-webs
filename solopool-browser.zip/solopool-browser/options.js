const DEFAULTS = { bgtabs: true, engine: "google" };

function load() {
  chrome.storage.local.get(["sp_options"], (res) => {
    const o = Object.assign({}, DEFAULTS, res.sp_options || {});
    document.getElementById("opt-bgtabs").checked = o.bgtabs;
    document.getElementById("opt-engine").value = o.engine;
  });
}

document.getElementById("save").addEventListener("click", () => {
  const o = {
    bgtabs: document.getElementById("opt-bgtabs").checked,
    engine: document.getElementById("opt-engine").value
  };
  chrome.storage.local.set({ sp_options: o }, () => {
    const s = document.getElementById("status");
    s.textContent = "Сохранено ✓";
    setTimeout(() => (s.textContent = ""), 1500);
  });
});

load();