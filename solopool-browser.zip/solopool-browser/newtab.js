function tick() {
  const now = new Date();
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  document.getElementById("clock").textContent = `${hh}:${mm}`;
  const opts = { weekday: "long", day: "numeric", month: "long" };
  document.getElementById("date").textContent = now.toLocaleDateString("ru-RU", opts);
}
tick();
setInterval(tick, 15000);

function go() {
  const q = document.getElementById("nt-q").value.trim();
  if (!q) return;
  // Если это похоже на ник (без пробелов) — предложим открыть сетку
  if (/^[a-zA-Z0-9_.-]{2,32}$/.test(q) && !q.includes(" ")) {
    chrome.storage.local.set({ sp_pending_grid: { query: q, mode: "username" } }, () => {
      window.location.href = "grid.html";
    });
  } else {
    window.location.href = `https://www.google.com/search?q=${encodeURIComponent(q)}`;
  }
}

document.getElementById("nt-go").addEventListener("click", go);
document.getElementById("nt-q").addEventListener("keydown", (e) => {
  if (e.key === "Enter") go();
});

document.getElementById("nt-board").addEventListener("click", () => {
  window.location.href = "board.html";
});
document.getElementById("nt-options").addEventListener("click", () => {
  if (chrome.runtime.openOptionsPage) chrome.runtime.openOptionsPage();
});