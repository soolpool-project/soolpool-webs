chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({id:"sp-reverse-image",title:"Solopool: Обратный поиск картинки",contexts:["image"]});
  chrome.contextMenus.create({id:"sp-search-selection",title:"Solopool: Искать выделенный текст",contexts:["selection"]});
  chrome.contextMenus.create({id:"sp-whois-page",title:"Solopool: WHOIS этого сайта",contexts:["page"]});
  chrome.contextMenus.create({id:"sp-wayback-page",title:"Solopool: Wayback Machine",contexts:["page"]});
  chrome.contextMenus.create({id:"sp-grid-selection",title:"Solopool: Построить сетку",contexts:["selection"]});
  chrome.contextMenus.create({id:"sp-open-board",title:"Solopool: Открыть доску зацепок",contexts:["page","selection","image"]});
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  const enc = (s) => encodeURIComponent(s);
  if (info.menuItemId === "sp-reverse-image" && info.srcUrl) {
    chrome.tabs.create({url:`https://lens.google.com/uploadbyurl?url=${enc(info.srcUrl)}`});
    chrome.tabs.create({url:`https://yandex.com/images/search?rpt=imageview&url=${enc(info.srcUrl)}`});
    chrome.tabs.create({url:`https://tineye.com/search?url=${enc(info.srcUrl)}`});
  }
  if (info.menuItemId === "sp-search-selection" && info.selectionText) {
    const t = info.selectionText.trim();
    chrome.tabs.create({url:`https://www.google.com/search?q=${enc(t)}`});
    chrome.tabs.create({url:`https://yandex.com/search/?text=${enc(t)}`});
  }
  if (info.menuItemId === "sp-grid-selection" && info.selectionText) {
    chrome.storage.local.set({sp_pending_grid:{query:info.selectionText.trim(),mode:"username"}},()=>{
      chrome.tabs.create({url:chrome.runtime.getURL("grid.html")});
    });
  }
  if (info.menuItemId === "sp-whois-page" && tab?.url) {
    try { chrome.tabs.create({url:`https://who.is/whois/${enc(new URL(tab.url).hostname)}`}); } catch(e){}
  }
  if (info.menuItemId === "sp-wayback-page" && tab?.url) {
    try { chrome.tabs.create({url:`https://web.archive.org/web/*/${enc(new URL(tab.url).hostname)}`}); } catch(e){}
  }
  if (info.menuItemId === "sp-open-board") {
    chrome.tabs.create({url:chrome.runtime.getURL("board.html")});
  }
});
