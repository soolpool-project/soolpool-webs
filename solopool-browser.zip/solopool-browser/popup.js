const q = (id) => document.getElementById(id)?.value.trim() || "";
const enc = (s) => encodeURIComponent(s);
const HISTORY_KEY = "sp_history_v1";
function openTabs(urls) { urls.forEach((u) => chrome.tabs.create({ url: u, active: false })); }
document.addEventListener("mousemove", (e) => {
  const btn = e.target.closest?.(".sp-btn"); if (!btn) return;
  const r = btn.getBoundingClientRect();
  btn.style.setProperty("--mx", (e.clientX - r.left) + "px");
  btn.style.setProperty("--my", (e.clientY - r.top) + "px");
});
document.querySelectorAll(".sp-tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".sp-tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".sp-panel").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById("tab-" + tab.dataset.tab).classList.add("active");
  });
});
function saveHistory(query, kind) {
  chrome.storage.local.get([HISTORY_KEY], (res) => {
    const list = res[HISTORY_KEY] || [];
    list.unshift({ query, kind, ts: Date.now() });
    const seen = new Set();
    const filtered = list.filter(item => {
      const k = item.kind + "::" + item.query;
      if (seen.has(k)) return false; seen.add(k); return true;
    }).slice(0, 50);
    chrome.storage.local.set({ [HISTORY_KEY]: filtered });
  });
}
document.querySelectorAll("#tab-search [data-action]").forEach(btn => {
  btn.addEventListener("click", () => {
    const query = q("q-search"); if (!query) return;
    const e = enc(query); saveHistory(query, "search");
    switch (btn.dataset.action) {
      case "dork-google": openTabs([`https://www.google.com/search?q=${e}`]); break;
      case "dork-yandex": openTabs([`https://yandex.com/search/?text=${e}`]); break;
      case "dork-duck": openTabs([`https://duckduckgo.com/?q=${e}`]); break;
      case "username-search":
        openTabs([
          `https://github.com/${e}`,`https://www.instagram.com/${e}`,
          `https://twitter.com/${e}`,`https://www.reddit.com/user/${e}`,
          `https://t.me/${e}`,`https://www.tiktok.com/@${e}`,
          `https://vk.com/${e}`,`https://www.pinterest.com/${e}`,
          `https://www.facebook.com/${e}`,`https://www.linkedin.com/in/${e}`
        ]); break;
    }
  });
});
document.getElementById("build-grid-search").addEventListener("click", () => {
  const query = q("q-search"); if (!query) return;
  saveHistory(query, "search");
  chrome.storage.local.set({ sp_pending_grid: { query, mode: "username" } }, () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("grid.html") });
  });
});
document.getElementById("build-grid-lookup").addEventListener("click", () => {
  const query = q("q-lookup"); if (!query) return;
  saveHistory(query, "lookup");
  chrome.storage.local.set({ sp_pending_grid: { query, mode: "domain" } }, () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("grid.html") });
  });
});
document.querySelectorAll("#tab-lookup [data-action]").forEach(btn => {
  btn.addEventListener("click", () => {
    const query = q("q-lookup"); if (!query) return;
    const e = enc(query); saveHistory(query, "lookup");
    switch (btn.dataset.action) {
      case "whois": openTabs([`https://who.is/whois/${e}`]); break;
      case "ipinfo": openTabs([`https://ipinfo.io/${e}`]); break;
      case "wayback": openTabs([`https://web.archive.org/web/*/${e}`]); break;
      case "breach": openTabs([`https://haveibeenpwned.com/account/${e}`]); break;
      case "dns": openTabs([`https://mxtoolbox.com/SuperTool.aspx?action=a%3a${e}&run=toolpage`]); break;
      case "ssl": openTabs([`https://crt.sh/?q=${e}`]); break;
    }
  });
});
function renderHistory() {
  const box = document.getElementById("history-list");
  chrome.storage.local.get([HISTORY_KEY], (res) => {
    const list = (res[HISTORY_KEY] || []).slice(0, 8);
    box.innerHTML = "";
    if (!list.length) { box.innerHTML = '<div class="sp-hint">Пока пусто.</div>'; return; }
    list.forEach(item => {
      const chip = document.createElement("div");
      chip.className = "sp-history-chip";
      chip.textContent = (item.kind === "search" ? "🔎 " : "🌐 ") + item.query;
      chip.addEventListener("click", () => {
        if (item.kind === "search") {
          document.getElementById("q-search").value = item.query;
          document.querySelector('.sp-tab[data-tab="search"]').click();
        } else {
          document.getElementById("q-lookup").value = item.query;
          document.querySelector('.sp-tab[data-tab="lookup"]').click();
        }
      });
      box.appendChild(chip);
    });
  });
}
renderHistory();
document.getElementById("open-board").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("board.html") }));
document.getElementById("open-grid").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("grid.html") }));
document.getElementById("open-options").addEventListener("click", () => chrome.runtime.openOptionsPage());
document.getElementById("open-current-tools").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) return;
  try {
    const host = new URL(tab.url).hostname;
    openTabs([`https://who.is/whois/${enc(host)}`,`https://web.archive.org/web/*/${enc(host)}`,`https://crt.sh/?q=${enc(host)}`]);
  } catch (e) {}
});
