// ============================================================
//  Solopool Grid v2 — честная проверка + ручные зацепки
// ============================================================
const STORAGE_KEY="sp_grid_v1",HISTORY_KEY="sp_history_v1",PENDING_KEY="sp_pending_grid";
const wrap=document.getElementById("wrap"),canvas=document.getElementById("canvas"),svg=document.getElementById("edges");
const nodeList=document.getElementById("node-list"),mini=document.getElementById("mini"),miniVp=document.getElementById("mini-vp");
const loading=document.getElementById("loading"),loadText=document.getElementById("loading-text"),progress=document.getElementById("progress-bar");

let state={query:"",mode:"username",nodes:[],edges:[],ts:Date.now()};
let scale=1,panX=0,panY=0,altDown=false;
const nodeEls=new Map();

const uid=()=>Math.random().toString(36).slice(2,10);
const esc=(s)=>(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

// ---------- Целевые сайты ----------
// api — функция возвращает URL публичного API, который отдаёт JSON + правильный 404
const PLATFORMS=[
  {id:"github",label:"GitHub",url:q=>`https://github.com/${q}`,api:q=>`https://api.github.com/users/${q}`},
  {id:"reddit",label:"Reddit",url:q=>`https://www.reddit.com/user/${q}`,api:q=>`https://www.reddit.com/user/${q}/about.json`},
  {id:"telegram",label:"Telegram",url:q=>`https://t.me/${q}`},
  {id:"instagram",label:"Instagram",url:q=>`https://www.instagram.com/${q}`},
  {id:"twitter",label:"Twitter/X",url:q=>`https://twitter.com/${q}`},
  {id:"tiktok",label:"TikTok",url:q=>`https://www.tiktok.com/@${q}`},
  {id:"vk",label:"VK",url:q=>`https://vk.com/${q}`},
  {id:"pinterest",label:"Pinterest",url:q=>`https://www.pinterest.com/${q}`},
  {id:"facebook",label:"Facebook",url:q=>`https://www.facebook.com/${q}`},
  {id:"linkedin",label:"LinkedIn",url:q=>`https://www.linkedin.com/in/${q}`},
  {id:"youtube",label:"YouTube",url:q=>`https://www.youtube.com/@${q}`},
  {id:"twitch",label:"Twitch",url:q=>`https://www.twitch.tv/${q}`},
  {id:"steam",label:"Steam",url:q=>`https://steamcommunity.com/id/${q}`},
  {id:"soundcloud",label:"SoundCloud",url:q=>`https://soundcloud.com/${q}`},
  {id:"medium",label:"Medium",url:q=>`https://medium.com/@${q}`}
];
const DOMAIN_CHECKS=[
  {id:"whois",label:"WHOIS",url:q=>`https://who.is/whois/${q}`},
  {id:"wayback",label:"Wayback",url:q=>`https://web.archive.org/web/*/${q}`},
  {id:"crtsh",label:"crt.sh",url:q=>`https://crt.sh/?q=${q}`},
  {id:"ipinfo",label:"IP / Geo",url:q=>`https://ipinfo.io/${q}`},
  {id:"virustotal",label:"VirusTotal",url:q=>`https://www.virustotal.com/gui/domain/${q}`},
  {id:"urlscan",label:"urlscan.io",url:q=>`https://urlscan.io/domain/${q}`},
  {id:"shodan",label:"Shodan",url:q=>`https://www.shodan.io/domain/${q}`}
];
const EMAIL_CHECKS=[
  {id:"hibp",label:"HaveIBeenPwned",url:q=>`https://haveibeenpwned.com/account/${q}`},
  {id:"github-search",label:"GitHub",url:q=>`https://github.com/search?q=${q}&type=users`},
  {id:"gravatar",label:"Gravatar",url:q=>`https://gravatar.com/${q}`}
];

// ============================================================
//  Честная проверка URL
// ============================================================
async function checkTarget(t){
  const q = state.query;
  const enc = encodeURIComponent(q);

  // 1) Если у платформы есть API — используем его
  if (t.api) {
    try {
      const r = await fetchWithTimeout(t.api(q), 8000, {headers:{"Accept":"application/json"}});
      if (r.status === 200) return "found";
      if (r.status === 404) return "unknown";
      if (r.status === 403 || r.status === 429) return "maybe"; // заблокировано
    } catch(e) { /* fallthrough */ }
  }

  // 2) Прямой fetch — читаем статус, если CORS позволит
  try {
    const r = await fetchWithTimeout(t.url(enc), 8000, {method:"GET",redirect:"follow"});
    if (r.status === 200) return "found";
    if (r.status === 404 || r.status === 410) return "unknown";
    if (r.status >= 500) return "maybe";
    return "maybe";
  } catch(e) {
    // CORS / network fail. Используем Image-тест: загружаем как картинку —
    // если onerror сработал быстро → скорее всего 404, если onload → есть контент
    return await imageProbe(t.url(enc));
  }
}

function fetchWithTimeout(url, ms, opts={}){
  const ctrl = new AbortController();
  const timer = setTimeout(()=>ctrl.abort(), ms);
  return fetch(url, {...opts, signal: ctrl.signal, cache:"no-store"})
    .finally(()=>clearTimeout(timer));
}

// Проверка через Image: не даёт 100% точности, но отсеивает явные 404
function imageProbe(url, timeout=5000){
  return new Promise(resolve=>{
    const img = new Image();
    let done = false;
    const to = setTimeout(()=>{ if(!done){done=true; img.src=""; resolve("maybe");}}, timeout);
    img.onload = ()=>{ if(!done){done=true; clearTimeout(to); resolve("found");}};
    img.onerror = ()=>{ if(!done){done=true; clearTimeout(to); resolve("unknown");}};
    img.referrerPolicy = "no-referrer";
    img.src = url;
  });
}

// ============================================================
//  Сохранение
// ============================================================
function save(){state.ts=Date.now();chrome.storage.local.set({[STORAGE_KEY]:state});}
function saveHistory(){
  chrome.storage.local.get([HISTORY_KEY],(res)=>{
    const list=res[HISTORY_KEY]||[];
    list.unshift({query:state.query,kind:state.mode,ts:Date.now()});
    const seen=new Set();
    const filtered=list.filter(x=>{const k=x.kind+"::"+x.query;if(seen.has(k))return false;seen.add(k);return true;}).slice(0,100);
    chrome.storage.local.set({[HISTORY_KEY]:filtered});
  });
}

// ============================================================
//  Раскладка
// ============================================================
function layout(){
  const cx=3500,cy=2500;
  const roots = state.nodes.filter(n=>n.root);
  if(roots[0]){roots[0].x=cx;roots[0].y=cy;}
  roots.slice(1).forEach((r,i)=>{r.x=cx+400+i*300;r.y=cy+400;});

  const children=state.nodes.filter(n=>!n.root);
  const N=children.length;if(!N)return;
  const perRing=8;
  children.forEach((n,i)=>{
    const ring=Math.floor(i/perRing);
    const idx=i%perRing;
    const radius=340+ring*260;
    const angle=(idx/perRing)*Math.PI*2+ring*0.3;
    n.x=cx+Math.cos(angle)*radius;
    n.y=cy+Math.sin(angle)*radius;
  });
}

// ============================================================
//  Трансформация и линии
// ============================================================
function applyTransform(){
  canvas.style.transform=`translate(${panX}px, ${panY}px) scale(${scale})`;
  svg.style.transform=canvas.style.transform;
  document.getElementById("zoom-level").textContent=Math.round(scale*100)+"%";
  // толщина линий компенсируется
  svg.querySelectorAll("path").forEach(p=>{
    const s = parseFloat(p.dataset.sw||"2");
    p.setAttribute("stroke-width",(s/scale).toString());
  });
  updateMini();
}

// Точный центр ноды в мировых координатах
function nodeCenter(n){
  const el=nodeEls.get(n.id);
  if(!el) return {x:n.x+100,y:n.y+40};
  // offsetWidth/Height НЕ зависят от CSS transform родителя
  const w = el.offsetWidth;
  const h = el.offsetHeight;
  return { x: n.x + w/2, y: n.y + h/2 };
}

function drawEdges(){
  svg.querySelectorAll("path").forEach(p=>p.remove());
  state.edges.forEach(e=>{
    const a=state.nodes.find(n=>n.id===e.from),b=state.nodes.find(n=>n.id===e.to);
    if(!a||!b)return;
    const ca=nodeCenter(a),cb=nodeCenter(b);
    const path=document.createElementNS("http://www.w3.org/2000/svg","path");
    const mx=(ca.x+cb.x)/2,my=(ca.y+cb.y)/2-40;
    path.setAttribute("d",`M ${ca.x} ${ca.y} Q ${mx} ${my} ${cb.x} ${cb.y}`);
    path.setAttribute("stroke",e.strong?"#3b8dff":"rgba(59,141,255,.45)");
    const sw = e.strong?2.2:1.4;
    path.dataset.sw = sw.toString();
    path.setAttribute("stroke-width",(sw/scale).toString());
    path.setAttribute("fill","none");
    path.setAttribute("stroke-linecap","round");
    path.setAttribute("opacity",e.strong?"0.9":"0.6");
    svg.appendChild(path);
  });
}

// ============================================================
//  Рендер
// ============================================================
function render(){
  canvas.innerHTML="";nodeEls.clear();
  state.nodes.forEach(n=>{
    const el=document.createElement("div");
    el.className="g-node"+(n.root?" root":"")+(n.manual?" manual":"");
    el.style.left=n.x+"px";el.style.top=n.y+"px";el.dataset.id=n.id;
    const statusText = n.status==="found"?"найдено":n.status==="maybe"?"возможно":n.status==="unknown"?"не найдено":"—";
    el.innerHTML=`
      <div class="kind">${esc(n.kindLabel||n.kind)}${n.manual?" · ручная":""}</div>
      <div class="val">${esc(n.value)}</div>
      <div class="meta"><span class="status ${n.status||"unknown"}"></span>${statusText}</div>
    `;
    el.addEventListener("click",(ev)=>{
      if(ev.altKey && n.value){
        // Alt+клик — сканировать дальше от этой зацепки
        rescanFrom(n);
        return;
      }
      focusNode(n);
      if(n.url)chrome.tabs.create({url:n.url,active:false});
    });
    canvas.appendChild(el);
    nodeEls.set(n.id,el);
    if(window.ResizeObserver){
      const ro=new ResizeObserver(()=>drawEdges());
      ro.observe(el);
      el._ro = ro;
    }
  });
  drawEdges();
  renderSidebar();
  updateMini();
}

function focusNode(n){
  const el=nodeEls.get(n.id);
  const w=el?el.offsetWidth:200;
  const h=el?el.offsetHeight:80;
  const vw=wrap.clientWidth,vh=wrap.clientHeight;
  const ts=Math.max(scale,1);
  panX=vw/2-n.x*ts-(w/2)*ts;
  panY=vh/2-n.y*ts-(h/2)*ts;
  scale=ts;
  applyTransform();
}

function renderSidebar(){
  const found=state.nodes.filter(n=>n.status==="found").length;
  const maybe=state.nodes.filter(n=>n.status==="maybe").length;
  document.getElementById("stat-found").textContent=found+" найдено";
  document.getElementById("stat-maybe").textContent=maybe+" похожих";
  document.getElementById("stat-all").textContent=state.nodes.length+" всего";

  nodeList.innerHTML="";
  state.nodes.forEach(n=>{
    const item=document.createElement("div");
    item.className="g-item"+(n.manual?" manual":"");
    const statusText = n.status==="found"?"✓":n.status==="maybe"?"?":n.status==="unknown"?"✗":"•";
    item.innerHTML=`<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${statusText} ${esc(n.value)}</span><span class="sp-badge">${esc(n.kindLabel||n.kind)}</span>`;
    item.addEventListener("click",()=>focusNode(n));
    item.addEventListener("dblclick",()=>{ if(n.value) rescanFrom(n); });
    nodeList.appendChild(item);
  });
}

function updateMini(){
  if(!state.nodes.length)return;
  const r=mini.getBoundingClientRect(),pad=8,W=r.width-pad*2,H=r.height-pad*2;
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  state.nodes.forEach(n=>{const el=nodeEls.get(n.id);const w=el?el.offsetWidth:200,h=el?el.offsetHeight:80;minX=Math.min(minX,n.x);minY=Math.min(minY,n.y);maxX=Math.max(maxX,n.x+w);maxY=Math.max(maxY,n.y+h);});
  const spanX=Math.max(maxX-minX,1),spanY=Math.max(maxY-minY,1);
  const k=Math.min(W/spanX,H/spanY);
  const sx=x=>pad+(x-minX)*k, sy=y=>pad+(y-minY)*k;
  mini.querySelectorAll(".mdot").forEach(d=>d.remove());
  state.nodes.forEach(n=>{
    const el=nodeEls.get(n.id);const w=el?el.offsetWidth:200,h=el?el.offsetHeight:80;
    const d=document.createElement("div");d.className="mdot"+(n.root?" root":"");d.style.left=sx(n.x+w/2)+"px";d.style.top=sy(n.y+h/2)+"px";mini.appendChild(d);
  });
  const vw=wrap.clientWidth,vh=wrap.clientHeight;
  const vx=-panX/scale,vy=-panY/scale,ww=vw/scale,hh=vh/scale;
  miniVp.style.left=sx(vx)+"px";miniVp.style.top=sy(vy)+"px";
  miniVp.style.width=Math.max(ww*k,8)+"px";miniVp.style.height=Math.max(hh*k,8)+"px";
}

function setProgress(p,t){progress.style.width=p+"%";if(t)loadText.textContent=t;}

// ============================================================
//  Сканирование
// ============================================================
async function scanRoot(){
  loading.classList.remove("hidden");
  setProgress(5,"Подготавливаю сетку...");
  state.nodes=[];state.edges=[];
  const q=state.query;
  const rootId=uid();
  state.nodes.push({id:rootId,root:true,kind:state.mode,kindLabel:"ЗАПРОС",value:q,status:"found",url:null});
  await scanFrom(rootId, q, state.mode);
  setProgress(100,"Готово");
  layout();save();saveHistory();
  setTimeout(()=>{loading.classList.add("hidden");fitAll();render();},350);
}

async function rescanFrom(node){
  if(!node.value) return;
  if(node.kind==="note"||node.kind==="person") {
    alert("Для этой зацепки нельзя выполнить скан (только ник / домен / email).");
    return;
  }
  loading.classList.remove("hidden");
  setProgress(10,`Сканирую от «${node.value}»...`);
  // удаляем старые дочерние рёбра от этого узла
  const oldEdges = state.edges.filter(e=>e.from===node.id);
  const oldChildIds = oldEdges.map(e=>e.to);
  state.edges = state.edges.filter(e=>e.from!==node.id);
  state.nodes = state.nodes.filter(n=>!oldChildIds.includes(n.id));
  await scanFrom(node.id, node.value, node.kind==="domain"?"domain":node.kind==="email"?"email":"username");
  layout();save();
  setTimeout(()=>{loading.classList.add("hidden");render();},300);
}

async function scanFrom(parentId, query, mode){
  const enc = encodeURIComponent(query);
  let targets = [];
  if(mode==="username") targets = PLATFORMS.slice();
  else if(mode==="domain") targets = DOMAIN_CHECKS.slice();
  else targets = EMAIL_CHECKS.slice();

  const total = targets.length;
  let done = 0;
  const results = [];
  const queue = targets.slice();

  async function worker(){
    while(queue.length){
      const t = queue.shift();
      let status;
      try {
        status = await checkTargetWithQuery(t, query);
      } catch(e){ status = "unknown"; }
      results.push({...t, url: t.url(enc), status});
      done++;
      setProgress(10+(done/total)*80, `[${query}] ${t.label} (${done}/${total})`);
    }
  }
  const CONCURRENCY = 5;
  await Promise.all(Array.from({length:CONCURRENCY}, worker));

  results.forEach(r=>{
    const id=uid();
    state.nodes.push({id,kind:r.id,kindLabel:r.label,value:r.label,status:r.status,url:r.url});
    state.edges.push({id:uid(),from:parentId,to:id,strong:r.status==="found"});
  });
}

async function checkTargetWithQuery(t, query){
  const enc = encodeURIComponent(query);
  // 1) API-проверка
  if (t.api) {
    try {
      const r = await fetchWithTimeout(t.api(query), 8000, {headers:{"Accept":"application/json"}});
      if (r.status === 200) return "found";
      if (r.status === 404) return "unknown";
      if (r.status === 403 || r.status === 429) return "maybe";
    } catch(e){}
  }
  // 2) Image-probe
  return await imageProbe(t.url(enc));
}

// ============================================================
//  Зум / пан
// ============================================================
let panning=false,psx=0,psy=0,pox=0,poy=0;
wrap.addEventListener("mousedown",e=>{
  if(e.target.closest(".g-node"))return;
  if(e.button!==0&&e.button!==1)return;
  panning=true;wrap.classList.add("grabbing");
  psx=e.clientX;psy=e.clientY;pox=panX;poy=panY;
});
window.addEventListener("mousemove",e=>{
  if(!panning)return;
  panX=pox+(e.clientX-psx);panY=poy+(e.clientY-psy);
  applyTransform();
});
window.addEventListener("mouseup",()=>{panning=false;wrap.classList.remove("grabbing");});
wrap.addEventListener("wheel",e=>{
  e.preventDefault();
  const r=wrap.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,os=scale;
  scale=Math.min(3,Math.max(0.15,scale*(1-e.deltaY*0.0018)));
  panX=mx-(mx-panX)*(scale/os);
  panY=my-(my-panY)*(scale/os);
  applyTransform();
},{passive:false});
document.getElementById("zoom-in").addEventListener("click",()=>{scale=Math.min(3,scale+0.15);applyTransform();});
document.getElementById("zoom-out").addEventListener("click",()=>{scale=Math.max(0.15,scale-0.15);applyTransform();});
document.getElementById("zoom-fit").addEventListener("click",fitAll);
document.getElementById("zoom-reset").addEventListener("click",()=>{scale=1;panX=0;panY=0;applyTransform();});

function fitAll(){
  if(!state.nodes.length)return;
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  state.nodes.forEach(n=>{const el=nodeEls.get(n.id);const w=el?el.offsetWidth:200,h=el?el.offsetHeight:80;minX=Math.min(minX,n.x);minY=Math.min(minY,n.y);maxX=Math.max(maxX,n.x+w);maxY=Math.max(maxY,n.y+h);});
  const w=wrap.clientWidth,h=wrap.clientHeight,pad=80;
  scale=Math.min((w-pad*2)/(maxX-minX),(h-pad*2)/(maxY-minY),1.2);
  panX=(w-(maxX-minX)*scale)/2-minX*scale;
  panY=(h-(maxY-minY)*scale)/2-minY*scale;
  applyTransform();
}

// Alt для подсказки
window.addEventListener("keydown",e=>{if(e.key==="Alt")altDown=true;});
window.addEventListener("keyup",e=>{if(e.key==="Alt")altDown=false;});

// ============================================================
//  Кнопки сайдбара
// ============================================================
document.getElementById("go-btn").addEventListener("click",()=>{
  const q=document.getElementById("new-query").value.trim();
  const m=document.getElementById("new-mode").value;
  if(!q)return;
  state.query=q;state.mode=m;
  document.getElementById("query-text").textContent=q;
  document.getElementById("mode-badge").textContent=m;
  document.getElementById("new-query").value="";
  scanRoot();
});
document.getElementById("rescan-btn").addEventListener("click",()=>{if(state.query)scanRoot();});

document.getElementById("add-lead-btn").addEventListener("click",()=>{
  const type=document.getElementById("lead-type").value;
  const val=prompt(`Значение зацепки (${type}):`,"");
  if(!val)return;
  const id=uid();
  // размещаем в мировых координатах рядом с центром видимой области
  const cx=(-panX+wrap.clientWidth/2)/scale;
  const cy=(-panY+wrap.clientHeight/2)/scale;
  const root = state.nodes.find(n=>n.root);
  const px = root ? root.x : cx;
  const py = root ? root.y : cy;
  state.nodes.push({
    id, kind:type, kindLabel:type, value:val, status:"unknown",
    url: type==="domain"?`https://${val}`:type==="username"?`https://github.com/${val}`:null,
    manual:true, x: px+200+Math.random()*200, y: py-200+Math.random()*400
  });
  if(root){
    state.edges.push({id:uid(),from:root.id,to:id,strong:false});
  }
  save();render();
});

document.getElementById("clear-btn").addEventListener("click",()=>{if(!confirm("Очистить?"))return;state={query:"",mode:"username",nodes:[],edges:[],ts:Date.now()};save();render();});
document.getElementById("export-btn").addEventListener("click",()=>{const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`solopool-grid-${state.query||"export"}.json`;a.click();URL.revokeObjectURL(url);});
document.getElementById("import-btn").addEventListener("click",()=>document.getElementById("import-file").click());
document.getElementById("import-file").addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const data=JSON.parse(r.result);if(data.nodes){state=data;document.getElementById("query-text").textContent=state.query||"—";document.getElementById("mode-badge").textContent=state.mode||"—";save();render();fitAll();}}catch{alert("Некорректный JSON");}};r.readAsText(f);});
window.addEventListener("resize",updateMini);

// ============================================================
//  Init
// ============================================================
function init(){
  chrome.storage.local.get([STORAGE_KEY,PENDING_KEY],res=>{
    const pending=res[PENDING_KEY];
    if(pending&&pending.query){
      state.query=pending.query;state.mode=pending.mode||"username";
      chrome.storage.local.remove(PENDING_KEY);
      document.getElementById("query-text").textContent=state.query;
      document.getElementById("mode-badge").textContent=state.mode;
      scanRoot();
      return;
    }
    if(res[STORAGE_KEY]&&res[STORAGE_KEY].nodes?.length){
      state=res[STORAGE_KEY];
      document.getElementById("query-text").textContent=state.query||"—";
      document.getElementById("mode-badge").textContent=state.mode||"—";
      render();fitAll();
    }else{
      document.getElementById("query-text").textContent="Введи запрос слева";
    }
  });
}
init();
